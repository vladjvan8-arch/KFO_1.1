package ru.kfo.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.view.View
import android.view.Gravity
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.TextView

class KfoKeyboardService : InputMethodService() {
    private val bg = Color.rgb(17, 24, 39)
    private val panel = Color.rgb(31, 42, 61)
    private val key = Color.rgb(49, 63, 84)
    private val blue = Color.rgb(120, 169, 255)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selected = "⌨ Клавиатура"
    private var shift = false
    private var english = false
    private var symbols = false

    // User-created content is intentionally empty on first launch.
    private val lectures = emptyList<String>()
    private val rpRoleplays = emptyList<String>()

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(4, 4, 4, 4)
        }
        val tabsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("⌨ Клавиатура", "Лекции", "RP отыгровки").forEach { tab ->
            val b = Button(this).apply {
                text = tab
                isAllCaps = false
                textSize = 11f
                setTextColor(if (selected == tab) blue else Color.WHITE)
                setBackgroundColor(if (selected == tab) Color.rgb(39, 61, 91) else panel)
                setOnClickListener { selected = tab; renderContent() }
            }
            val lp = LinearLayout.LayoutParams(-2, 42)
            lp.setMargins(2, 0, 2, 0)
            tabs.addView(b, lp)
        }
        tabsScroll.addView(tabs)
        root.addView(tabsScroll, LinearLayout.LayoutParams(-1, 44))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        renderContent()
        return root
    }

    private fun renderContent() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        if (selected == "⌨ Клавиатура") {
            val hint = TextView(this).apply {
                text = "Ввод сообщения"
                setTextColor(Color.LTGRAY); textSize = 11f; gravity = Gravity.CENTER
            }
            content.addView(hint, LinearLayout.LayoutParams(-1, 22))
            addLetterKeyboard(content)
            return
        }
        when (selected) {
            "Лекции" -> {
                addSectionTitle("Лекции выбранной организации")
                addItems(lectures)
            }
            "RP отыгровки" -> {
                addSectionTitle("RP отыгровки")
                addItems(rpRoleplays)
            }
        }
    }

    private fun addSectionTitle(title: String) {
        val t = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE); textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 4, 10, 4)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, 38))
    }

    private fun addItems(items: List<String>) {
        if (items.isEmpty()) {
            val empty = TextView(this).apply {
                text = if (selected == "Лекции") "Пока нет лекций. Добавь их в основном приложении KFO." else "Пока нет RP-отыгровок. Добавь их в основном приложении KFO."
                setTextColor(Color.LTGRAY)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(16, 12, 16, 12)
            }
            content.addView(empty, LinearLayout.LayoutParams(-1, -1))
            return
        }
        val scroller = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.forEach { item ->
            val b = Button(this).apply {
                text = item
                isAllCaps = false
                textSize = 13f
                setTextColor(Color.WHITE)
                setBackgroundColor(panel)
                gravity = Gravity.CENTER_VERTICAL
                setOnClickListener {
                    currentInputConnection?.commitText("$item ", 1)
                }
            }
            val lp = LinearLayout.LayoutParams(-1, 48)
            lp.setMargins(2, 3, 2, 3)
            list.addView(b, lp)
        }
        scroller.addView(list)
        content.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun addLetterKeyboard(parent: LinearLayout) {
        val divider = View(this).apply { setBackgroundColor(Color.rgb(66, 78, 98)) }
        parent.addView(divider, LinearLayout.LayoutParams(-1, 1))
        val rows: List<List<String>> = when {
            symbols -> listOf(
                listOf("1","2","3","4","5","6","7","8","9","0"),
                listOf("@","#","$","%","&","-","+","(",")","/"),
                listOf("*","\"","'",";",":","!","?","⌫"),
                listOf("ABC",",","Пробел",".","↵")
            )
            english -> listOf(
                listOf("q","w","e","r","t","y","u","i","o","p"),
                listOf("a","s","d","f","g","h","j","k","l"),
                listOf("⇧","z","x","c","v","b","n","m","⌫"),
                listOf("?123","РУС",",","Пробел",".","↵")
            )
            else -> listOf(
                listOf("й","ц","у","к","е","н","г","ш","щ","з","х"),
                listOf("ф","ы","в","а","п","р","о","л","д","ж","э"),
                listOf("⇧","я","ч","с","м","и","т","ь","б","ю","⌫"),
                listOf("?123","ENG",",","Пробел",".","↵")
            )
        }
        rows.forEachIndexed { rowIndex, labels ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            labels.forEach { label ->
                val weight = when (label) {
                    "Пробел" -> 4.2f
                    "?123", "ABC", "⇧", "⌫", "↵", "ENG", "РУС" -> 1.45f
                    else -> 1f
                }
                val b = Button(this).apply {
                    text = if (shift && label.length == 1 && label[0].isLetter()) label.uppercase() else label
                    isAllCaps = false
                    textSize = if (label == "Пробел") 11f else 15f
                    setTextColor(Color.WHITE)
                    setBackgroundColor(if (label in listOf("Пробел","↵","⌫","⇧","?123","ABC","ENG","РУС")) panel else key)
                    setPadding(0, 0, 0, 0)
                    setOnClickListener { handleKey(label) }
                }
                val lp = LinearLayout.LayoutParams(0, 45, weight)
                lp.setMargins(2, 2, 2, 2)
                row.addView(b, lp)
            }
            parent.addView(row, LinearLayout.LayoutParams(-1, 49))
        }
    }

    private fun handleKey(label: String) {
        val ic: InputConnection? = currentInputConnection
        when (label) {
            "⇧" -> { shift = !shift; refreshKeyboard() }
            "⌫" -> ic?.deleteSurroundingText(1, 0)
            "Пробел" -> ic?.commitText(" ", 1)
            "↵" -> ic?.commitText("\n", 1)
            "?123" -> { symbols = true; refreshKeyboard() }
            "ABC" -> { symbols = false; refreshKeyboard() }
            "ENG" -> { english = true; symbols = false; refreshKeyboard() }
            "РУС" -> { english = false; symbols = false; refreshKeyboard() }
            "," , "." -> ic?.commitText(label, 1)
            else -> {
                val value = if (shift && label.length == 1 && label[0].isLetter()) label.uppercase() else label
                ic?.commitText(value, 1)
                if (shift) { shift = false; refreshKeyboard() }
            }
        }
    }

    private fun refreshKeyboard() {
        selected = "⌨ Клавиатура"
        setInputView(onCreateInputView())
    }
}
