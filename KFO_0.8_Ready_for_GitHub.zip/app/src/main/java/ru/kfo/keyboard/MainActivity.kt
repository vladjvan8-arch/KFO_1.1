package ru.kfo.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF111827)
private val Panel = Color(0xFF1F2A3D)
private val Blue = Color(0xFF78A9FF)
private val Muted = Color(0xFF9AAAC2)

data class Phrase(val title: String, val text: String)
data class LecturePart(val title: String, val body: String)
data class Lecture(val title: String, val organization: String, val parts: List<LecturePart>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KfoHome(
                onCopy = { text ->
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("KFO", text))
                },
                onEnableKeyboard = { startActivity(Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS)) },
                onChooseKeyboard = {
                    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.showInputMethodPicker()
                }
            )
        }
    }
}

@Composable
fun KfoHome(onCopy: (String) -> Unit, onEnableKeyboard: () -> Unit, onChooseKeyboard: () -> Unit) {
    val phrases = emptyList<Phrase>()
    // Each organization starts with an empty lecture collection. Users add their own content.
    val lecturesByOrg = remember {
        mapOf<String, List<Lecture>>(
            "ФСБ" to emptyList(),
            "МВД" to emptyList(),
            "Правительство" to emptyList(),
            "МЗ" to emptyList()
        )
    }

    var selectedOrg by remember { mutableStateOf("ФСБ") }
    var selectedLectureIndex by remember { mutableIntStateOf(0) }
    var selectedTab by remember { mutableStateOf("Главная") }
    var query by remember { mutableStateOf("") }
    var activeLecture by remember { mutableStateOf(false) }
    var currentPart by remember { mutableIntStateOf(0) }
    var interrupted by remember { mutableStateOf(false) }
    var showKeys by remember { mutableStateOf(true) }
    var allLectures by remember { mutableStateOf(lecturesByOrg.toMutableMap()) }
    var showAddLecture by remember { mutableStateOf(false) }
    var showAddPart by remember { mutableStateOf(false) }
    var partTargetIndex by remember { mutableIntStateOf(0) }
    var draftTitle by remember { mutableStateOf("") }
    var draftBody by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Navy).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                    Text("KFO", Modifier.padding(horizontal = 13.dp, vertical = 10.dp),
                        color = Blue, fontWeight = FontWeight.Black, fontSize = 22.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Keyboard for Organizations", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Помощник вашей организации · версия 0.8", color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))

            if (activeLecture) {
                LectureRunner(
                    lecture = (allLectures[selectedOrg] ?: emptyList()).getOrElse(selectedLectureIndex) { (allLectures[selectedOrg] ?: emptyList()).first() },
                    currentPart = currentPart,
                    interrupted = interrupted,
                    showKeys = showKeys,
                    onPart = { currentPart = it; interrupted = false },
                    onInterrupt = { interrupted = true },
                    onResume = { interrupted = false },
                    onToggleKeys = { showKeys = !showKeys },
                    onCopy = onCopy,
                    onClose = { activeLecture = false; interrupted = false; currentPart = 0 }
                )
            } else {
                Text("Добро пожаловать!", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Быстрый доступ к материалам организации", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                val tabs = listOf("Главная", "Лекции", "Настройки")
                tabs.chunked(3).forEach { rowTabs ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        rowTabs.forEach { tab ->
                            FilterChip(selectedTab == tab, onClick = { selectedTab = tab },
                                label = { Text(tab, fontSize = 12.sp) })
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                when (selectedTab) {
                    "Главная" -> {
                        InfoCard("Профиль организации", "Выбранная организация: $selectedOrg")
                        InfoCard("Начало работы", "Добавь собственные лекции в разделе «Лекции».")
                    }
                    "Лекции" -> {
                        val currentOrgLectures = allLectures[selectedOrg] ?: emptyList()
                        Text("Лекции организаций", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text("Выбери свою организацию — у каждой свой список материалов.", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        var orgMenu by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { orgMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Организация: $selectedOrg")
                            }
                            DropdownMenu(expanded = orgMenu, onDismissRequest = { orgMenu = false }) {
                                lecturesByOrg.keys.forEach { org ->
                                    DropdownMenuItem(text = { Text(org) }, onClick = {
                                        selectedOrg = org
                                        selectedLectureIndex = 0
                                        orgMenu = false
                                    })
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Доступные лекции", color = Blue, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { draftTitle = ""; draftBody = ""; showAddLecture = true }) { Text("+ Добавить лекцию") }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(currentOrgLectures) { index, item ->
                                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(item.title, color = Color.White, fontWeight = FontWeight.Bold)
                                        Text("${item.parts.size} частей", color = Muted, fontSize = 12.sp)
                                        Spacer(Modifier.height(8.dp))
                                        Button(onClick = {
                                            selectedLectureIndex = index
                                            activeLecture = true
                                            currentPart = 0
                                            interrupted = false
                                        }, modifier = Modifier.fillMaxWidth()) { Text("Открыть лекцию") }
                                        OutlinedButton(onClick = {
                                            partTargetIndex = index
                                            draftTitle = ""
                                            draftBody = ""
                                            showAddPart = true
                                        }, modifier = Modifier.fillMaxWidth()) { Text("+ Добавить текст / часть") }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("После нажатия на часть следующая часть подсвечивается красным — видно, что отправлять дальше.", color = Muted, fontSize = 13.sp)
                    }
                    "Изображения" -> InfoCard("Изображения", "Здесь будет библиотека изображений организации.")
                    "Действия" -> InfoCard("Действия", "Здесь будут быстрые RP-действия и события.")
                    else -> {
                        InfoCard("Клавиатура KFO", "Включи KFO в настройках клавиатур Android, затем выбери её как текущую.")
                        Button(onClick = onEnableKeyboard, Modifier.fillMaxWidth()) { Text("Включить клавиатуру") }
                        OutlinedButton(onClick = onChooseKeyboard, Modifier.fillMaxWidth()) { Text("Выбрать KFO") }
                    }
                }
            }
        }
        if (showAddLecture) {
            AlertDialog(
                onDismissRequest = { showAddLecture = false },
                title = { Text("Новая лекция — $selectedOrg") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = draftTitle, onValueChange = { draftTitle = it }, label = { Text("Название лекции") }, singleLine = true)
                        OutlinedTextField(value = draftBody, onValueChange = { draftBody = it }, label = { Text("Текст первой части") }, minLines = 4)
                    }
                },
                confirmButton = { TextButton(onClick = {
                    if (draftTitle.isNotBlank() && draftBody.isNotBlank()) {
                        val updated = (allLectures[selectedOrg] ?: emptyList()) + Lecture(draftTitle.trim(), selectedOrg, listOf(LecturePart("1. ${draftTitle.trim()}", draftBody.trim())))
                        allLectures = allLectures.toMutableMap().apply { put(selectedOrg, updated) }
                    }
                    showAddLecture = false
                }) { Text("Сохранить") } },
                dismissButton = { TextButton(onClick = { showAddLecture = false }) { Text("Отмена") } }
            )
        }
        if (showAddPart) {
            AlertDialog(
                onDismissRequest = { showAddPart = false },
                title = { Text("Добавить текст в лекцию") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = draftTitle, onValueChange = { draftTitle = it }, label = { Text("Название части") }, singleLine = true)
                        OutlinedTextField(value = draftBody, onValueChange = { draftBody = it }, label = { Text("Текст") }, minLines = 5)
                        Text("После сохранения ты останешься в разделе «Лекции».", color = Muted, fontSize = 12.sp)
                    }
                },
                confirmButton = { TextButton(onClick = {
                    if (draftBody.isNotBlank()) {
                        val updatedMap = allLectures.toMutableMap()
                        val list = (updatedMap[selectedOrg] ?: emptyList()).toMutableList()
                        if (partTargetIndex in list.indices) {
                            val old = list[partTargetIndex]
                            val nextNumber = old.parts.size + 1
                            val partName = draftTitle.ifBlank { "Часть $nextNumber" }
                            list[partTargetIndex] = old.copy(parts = old.parts + LecturePart("$nextNumber. $partName", draftBody.trim()))
                            updatedMap[selectedOrg] = list
                            allLectures = updatedMap
                        }
                    }
                    showAddPart = false
                }) { Text("Сохранить") } },
                dismissButton = { TextButton(onClick = { showAddPart = false }) { Text("Отмена") } }
            )
        }
    }
}

@Composable
private fun LectureRunner(
    lecture: Lecture, currentPart: Int, interrupted: Boolean, showKeys: Boolean,
    onPart: (Int) -> Unit, onInterrupt: () -> Unit, onResume: () -> Unit,
    onToggleKeys: () -> Unit, onCopy: (String) -> Unit, onClose: () -> Unit
) {
    Text(lecture.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text("Отправляешь: ${currentPart + 1} · Следующая подсвечена красным", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        lecture.parts.forEachIndexed { index, _ ->
            val isCurrent = index == currentPart
            val isNext = index == currentPart + 1
            Button(onClick = { onPart(index) }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when {
                        isCurrent -> Blue
                        isNext -> Color(0xFFE53935)
                        else -> Panel
                    }
                )) {
                Text("${index + 1}", color = if (isCurrent) Navy else Color.White)
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    val part = lecture.parts[currentPart]
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(part.title, color = Blue, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(part.body, color = Color.White, fontSize = 15.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onCopy(part.body) }, modifier = Modifier.fillMaxWidth()) {
                Text("Копировать часть ${currentPart + 1}")
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    if (interrupted) {
        Surface(color = Color(0xFF493B24), shape = RoundedCornerShape(12.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text("Лекция приостановлена", color = Color(0xFFFFD38A), fontWeight = FontWeight.Bold)
                Text("Тебя перебили или задали вопрос. Ответь в игровом чате, затем продолжи с нужной части.", color = Color.White, fontSize = 13.sp)
                Button(onClick = onResume, modifier = Modifier.fillMaxWidth()) { Text("Продолжить лекцию") }
            }
        }
    } else {
        OutlinedButton(onClick = onInterrupt, modifier = Modifier.fillMaxWidth()) {
            Text("Пауза / меня перебили / вопрос")
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { onPart((currentPart - 1).coerceAtLeast(0)) }, modifier = Modifier.weight(1f)) { Text("Назад") }
        Button(onClick = { onPart((currentPart + 1).coerceAtMost(lecture.parts.lastIndex)) },
            modifier = Modifier.weight(1f), enabled = currentPart < lecture.parts.lastIndex) { Text("Следующая часть") }
    }
    TextButton(onClick = onToggleKeys) { Text(if (showKeys) "Скрыть подсказки кнопок" else "Показать подсказки кнопок") }
    if (showKeys) {
        Text("Подсказки: 1–${lecture.parts.size} — выбрать часть · Пауза — остановить лекцию · Продолжить — вернуться к материалу · Копировать — перенести текст в чат.",
            color = Muted, fontSize = 12.sp)
    }
    TextButton(onClick = onClose) { Text("Завершить лекцию") }
}

@Composable
private fun CopyCard(title: String, body: String, onCopy: (String) -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(title, color = Blue, fontWeight = FontWeight.Bold)
            Text(body, color = Color.White, fontSize = 14.sp)
            TextButton(onClick = { onCopy(body) }) { Text("Копировать") }
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Blue, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(body, color = Muted, fontSize = 13.sp)
        }
    }
}
